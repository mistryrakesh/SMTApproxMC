#!/bin/bash

rm -f runBenchmarks.log

DIR_LIST=`cat dir_list.txt`

for i in `ls -d $DIR_LIST`
do
    rm -rf $i"finalOutput.txt" $i"runlog.txt" $i"temp_amc"
done
