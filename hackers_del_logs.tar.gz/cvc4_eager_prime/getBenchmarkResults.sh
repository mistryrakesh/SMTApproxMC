#!/bin/bash

OUTPUT_FILE="$1"

while IFS='' read -r line || [[ -n "$line" ]]
do
    DIR_NAME=`ls -d $line`
    printf "$DIR_NAME;" >> "$OUTPUT_FILE"
    cat "$DIR_NAME""finalOutput.txt" >> "$OUTPUT_FILE"
    printf "\n" >> "$OUTPUT_FILE"
done < "dir_list.txt"
