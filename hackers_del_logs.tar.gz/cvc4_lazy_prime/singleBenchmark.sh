#!/bin/bash

DIR_PATH=`readlink -f $1`
DIR_NAME=`basename $DIR_PATH`

cd "$DIR_NAME"
SMT2FILE=`ls *.smt2 | head -1`
python3 /home/rakeshmistry/Documents/approxMC/scripts/approxMC_cvc4_lazy.py "$SMT2FILE" /home/rakeshmistry/Documents/approxMC/primes.txt 7 runlog.txt finalOutput.txt
