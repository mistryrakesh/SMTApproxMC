#!/bin/bash

#PBS -q batch
#PBS -k eo
#PBS -l nodes=5:ppn=5,walltime=10:00:00
#PBS -N hack_del_bx

cd $PBS_O_WORKDIR

DIR_LIST=`cat dir_list.txt`

ls -1 -d $DIR_LIST | parallel --joblog runBenchmarks.log --sshloginfile $PBS_NODEFILE --workdir $PWD './singleBenchmark.sh {}'
