#!/bin/bash

#PBS -q batch
#PBS -k eo
#PBS -l nodes=8:ppn=20,walltime=10:00:00
#PBS -N approxMC_Benchmarks

cd $PBS_O_WORKDIR

ls -1 -d */ | parallel --joblog runBenchmarks.log --sshloginfile $PBS_NODEFILE --workdir $PWD './singleBenchmark.sh {}'
