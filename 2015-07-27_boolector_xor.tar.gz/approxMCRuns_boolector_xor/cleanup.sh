#!/bin/bash

rm -f runBenchmarks.log

for i in `ls -d */`
do
    rm -rf $i"finalOutput.csv" $i"run.log" $i"temp_amc"
done
