#!/bin/bash

OUTPUT_FILE="$1"

for dir in `ls -d */`
do
    time=0
    numTimeout=0

    for i in `sed -n 's/cmd time: //p' "$dir"run.log`
    do
	time=$(echo "$time + $i" | bc)
	if [ $(echo "$i + 20 > 2500" | bc) -eq 1 ] ; then
	    numTimeout=$((numTimeout + 1))
	fi
    done

    printf "$dir,$time,$numTimeout\n" >> "$OUTPUT_FILE"
done
