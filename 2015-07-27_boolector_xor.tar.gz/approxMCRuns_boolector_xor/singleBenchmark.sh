#!/bin/bash

DIR_PATH=`readlink -f $1`
DIR_NAME=`basename $DIR_PATH`

cd "$DIR_NAME"
python3 /home/rakeshmistry/Documents/approxMC/approxMC_xor.py "$DIR_NAME.smt2" 7 run.log finalOutput.csv
